﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Hospital_Bed_Availability_Website
{
    public partial class RegionII : System.Web.UI.Page
    {
        string strcon = ConfigurationManager.ConnectionStrings["con"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void Button1_Click(object sender, EventArgs e)
        {

            signupNewUser();
        }

        void signupNewUser()
        {
            //Response.Write("<script>alert('Testing');</script>");
            try
            {
                SqlConnection con = new SqlConnection(strcon);
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }

                SqlCommand cmd = new SqlCommand("INSERT INTO Region2(hospital_name,address,tel_num,email,provinces,covid19_cases,noncovid19_cases,username,pass) values(@hospital_name,@address,@tel_num,@email,@provinces,@covid19_cases,@noncovid19_cases,@username,@pass)", con);

                cmd.Parameters.AddWithValue("@hospital_name", TextBox3.Text.Trim());
                cmd.Parameters.AddWithValue("@address", TextBox4.Text.Trim());
                cmd.Parameters.AddWithValue("@tel_num", TextBox1.Text.Trim());
                cmd.Parameters.AddWithValue("@email", TextBox2.Text.Trim());
                cmd.Parameters.AddWithValue("@provinces", DropDownList3.SelectedItem.Value);
                cmd.Parameters.AddWithValue("@covid19_cases", DropDownList1.SelectedItem.Value);
                cmd.Parameters.AddWithValue("@noncovid19_cases", DropDownList2.SelectedItem.Value);
                cmd.Parameters.AddWithValue("@username", TextBox5.Text.Trim());
                cmd.Parameters.AddWithValue("@pass", TextBox6.Text.Trim());

                cmd.ExecuteNonQuery();
                con.Close();
                Response.Write("<script> alert ('Sign Up successful!. Proceed to Hospital Login located at the foooter of the website');</script");

            }
            catch (Exception ex)
            {
                Response.Write("<script> alert ('" + ex.Message
                     + "'); </script>");
            }
        }
    }
}